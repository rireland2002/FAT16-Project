#include <stdio.h>
#include <stdlib.h>
#include<stdint.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>

typedef struct __attribute__((__packed__)){
    uint8_t BS_jmpBoot[ 3 ]; // x86 jump instr. to boot code
    uint8_t BS_OEMName[ 8 ]; // What created the filesystem
    uint16_t BPB_BytsPerSec; // Bytes per Sector
    uint8_t BPB_SecPerClus; // Sectors per Cluster
    uint16_t BPB_RsvdSecCnt; // Reserved Sector Count
    uint8_t BPB_NumFATs; // Number of copies of FAT
    uint16_t BPB_RootEntCnt; // FAT12/FAT16: size of root DIR
    uint16_t BPB_TotSec16; // Sectors, may be 0, see below
    uint8_t BPB_Media; // Media type, e.g. fixed
    uint16_t BPB_FATSz16; // Sectors in FAT (FAT12 or FAT16)
    uint16_t BPB_SecPerTrk; // Sectors per Track
    uint16_t BPB_NumHeads; // Number of heads in disk
    uint32_t BPB_HiddSec; // Hidden Sector count
    uint32_t BPB_TotSec32; // Sectors if BPB_TotSec16 == 0
    uint8_t BS_DrvNum; // 0 = floppy, 0x80 = hard disk
    uint8_t BS_Reserved1; //
    uint8_t BS_BootSig; // Should = 0x29
    uint32_t BS_VolID; // 'Unique' ID for volume
    uint8_t BS_VolLab[ 11 ]; // Non zero terminated string
    uint8_t BS_FilSysType[ 8 ]; // e.g. 'FAT16 ' (Not 0 term.)
    }BootSector;

typedef struct __attribute__((__packed__)){
	uint8_t		DIR_Name[ 11 ];		// Non zero terminated string
	uint8_t		DIR_Attr;		// File attributes
	uint8_t		DIR_NTRes;		// Used by Windows NT, ignore
	uint8_t		DIR_CrtTimeTenth;	// Tenths of sec. 0..199
	uint16_t	DIR_CrtTime;		// Creation Time in 2s intervals
	uint16_t	DIR_CrtDate;
	uint16_t	DIR_LstAccDate;		// Date of last read or write
	uint16_t	DIR_FstClusHI;		// Top bits file's 1st cluster
	uint16_t	DIR_WrtTime;		// Time of last write
	uint16_t	DIR_WrtDate;		// Date of last write
	uint16_t	DIR_FstClusLO;		// Lower bits file's 1st cluster
	uint32_t	DIR_FileSize;		// File size in bytes
}DirectoryShort;

typedef struct __attribute__((packed)){
uint8_t LDIR_Ord; // Order/ position in sequence/ set
uint8_t LDIR_Name1[ 10 ]; // First 5 UNICODE characters
uint8_t LDIR_Attr; // = ATTR_LONG_NAME (xx001111)
uint8_t LDIR_Type; // Should = 0
uint8_t LDIR_Chksum; // Checksum of short name
uint8_t LDIR_Name2[ 12 ]; // Middle 6 UNICODE characters
uint16_t LDIR_FstClusLO; // MUST be zero
uint8_t LDIR_Name3[ 4 ]; // Last 2 UNICODE characters
}DirectoryLong;

int readShortFile(DirectoryShort a, int filemain, uint16_t clusBuf[]);
void longFile(DirectoryShort[]);
int fileClusters(int clusternum, u_int16_t clusBuf[], BootSector* bootPoint);

int main(){
    BootSector* bootPointer = (BootSector*) malloc(sizeof(BootSector));
    DirectoryShort* shortPointer = malloc(sizeof(DirectoryShort));
    int bootSize = sizeof(BootSector);
    int file = open("fat16.img",O_RDONLY);
    read(file,bootPointer,bootSize);
    printf("BytesPerSector: %d\nSectorsPerCluster: %d\nReservedSectorCount: %d\nNumberOfCopies: %d\nSizeOfRootDir: %d\nTotalSectors %d\nSectorsInFat16: %d\nSectorsInFat32: %d\n",bootPointer->BPB_BytsPerSec,bootPointer->BPB_SecPerClus,bootPointer->BPB_RsvdSecCnt,bootPointer->BPB_NumFATs,bootPointer->BPB_RootEntCnt,bootPointer->BPB_TotSec16,bootPointer-> BPB_FATSz16,bootPointer->BPB_TotSec32);
    DirectoryShort dirShortArray[bootPointer->BPB_RootEntCnt];
    for(int i = 0; i<11; i++)
    {
            printf("%c", bootPointer->BS_VolLab[i]);
    }
    printf("\n");
    
    uint16_t clusterBuffer[bootPointer->BPB_FATSz16 * bootPointer->BPB_BytsPerSec/2];
    
    lseek(file,2048,SEEK_SET);
    read(file, clusterBuffer, bootPointer->BPB_FATSz16*bootPointer->BPB_BytsPerSec);
 
    fileClusters(233,clusterBuffer,bootPointer);

    lseek(file,34816,SEEK_SET);
     
    for(int i = 0; i<bootPointer->BPB_RootEntCnt ;i++)
    {
    read(file,shortPointer,sizeof(DirectoryShort));
    dirShortArray[i] = *shortPointer;
    }

    for(int x = 0; x<bootPointer->BPB_RootEntCnt; x++)
    {
        if(dirShortArray[x].DIR_Name[0] == 0)
        {
            break;
        }
        if(((dirShortArray[x].DIR_Attr>>1)&1) == 1  & ((dirShortArray[x].DIR_Attr>>2)&1) == 1 & ((dirShortArray[x].DIR_Attr>>3)&1) == 1)
        {
            continue;
        }
        printf("File Index:%d",x);
        printf("\t");
        for(int i = 0; i<11; i++)
        {
            printf("%c",dirShortArray[x].DIR_Name[i]);
        }
        printf("\t");
        for(int i = 0; i <6; i++)
        {
           if(i==0 & (dirShortArray[x].DIR_Attr>>i)&1 == 1)
                {
                    printf("R");
                }
                else if(i==1 & (dirShortArray[x].DIR_Attr>>i)&1 == 1)
                {
                    printf("H");
                }
                else if(i==2 & (dirShortArray[x].DIR_Attr>>i)&1 == 1)
                    {
                        printf("S");
                    }
                else if(i==3 & (dirShortArray[x].DIR_Attr>>i)&1 == 1)
                    {
                        printf("V");
                    }
                else if(i==4 & (dirShortArray[x].DIR_Attr>>i)&1 == 1)
                    {
                        printf("D");
                    }
                else if(i==5 & (dirShortArray[x].DIR_Attr>>i)&1 == 1)
                    {
                        printf("A");
                    }
                else
                    {
                        printf("-");
                    }
        }
        printf("\t");
        printf("Starting Cluster: %d",dirShortArray[x].DIR_FstClusHI+dirShortArray[x].DIR_FstClusLO);
        printf("\t");
        printf("Y:%d M:%d D:%d", 1980+((dirShortArray[x].DIR_WrtDate&0x7C00)>>10),((dirShortArray[x].DIR_WrtDate & 0x3E0)>>5),(dirShortArray[x].DIR_WrtDate & 0x1F));
        printf("\t");
        printf("H:%d M:%d S:%d",((dirShortArray[x].DIR_WrtTime&0x7C00)>>10),((dirShortArray[x].DIR_WrtTime & 0x3E0)>>5),(dirShortArray[x].DIR_WrtTime & 0x1F));
        printf("\t");        
        printf("File Size:%d",dirShortArray[x].DIR_FileSize);
        printf("\n");
    }
   
    readShortFile(dirShortArray[18], file, clusterBuffer);
    longFile(dirShortArray);

    close(file);
}

int readShortFile(DirectoryShort a, int filemain, uint16_t clusBuf[])
{
    char* buffer = malloc(a.DIR_FileSize);
    uint32_t dirCluster = a.DIR_FstClusHI + a.DIR_FstClusLO;
    double clusCount = a.DIR_FileSize/2048.0;
    int clusCount2 = a.DIR_FileSize/2048;
    lseek(filemain, (dirCluster+23)*2048, SEEK_SET);
    for(int i = 0; i < clusCount2; i++)
    {
        read(filemain,buffer+(i*2048),2048);
        if(dirCluster==65535)
        {
            break;
        }
        dirCluster = clusBuf[dirCluster];
        lseek(filemain, (dirCluster+23)*2048, SEEK_SET);
        clusCount--;
    }
    read(filemain,buffer,clusCount*2048.0);

    for(int i = 0; i<a.DIR_FileSize; i++)
    {
        printf("%c",buffer[i]);
    }
}

void longFile(DirectoryShort dirLongArray[])
{
    for(int i = 0; i<512;i++)
    {
        if(dirLongArray[i].DIR_Attr !=0)//Check if directory is null
        {
            if(dirLongArray[i].DIR_Attr == 15)//Check for long
            {
                DirectoryLong* longEntry = (DirectoryLong*)&dirLongArray[i];
                if(longEntry->LDIR_Attr == '\017')//Check if directory is corrupt
                {
                    while(dirLongArray[i].DIR_Attr == 15)//While entry is a long
                    {
                        i++;//Find final long
                    }
                    printf("File Index:%d",i);
                    printf("\t");
                    printf("Starting Cluster: %d",dirLongArray[i].DIR_FstClusHI+dirLongArray[i].DIR_FstClusLO);//Printing out directory content
                    printf("\t");
                    printf("Y:%d M:%d D:%d", 1980+((dirLongArray[i].DIR_WrtDate&0x7C00)>>10),((dirLongArray[i].DIR_WrtDate & 0x3E0)>>5),(dirLongArray[i].DIR_WrtDate & 0x1F));
                    printf("\t");
                    printf("H:%d M:%d S:%d",((dirLongArray[i].DIR_WrtTime&0x7C00)>>10),((dirLongArray[i].DIR_WrtTime & 0x3E0)>>5),(dirLongArray[i].DIR_WrtTime & 0x1F));
                    printf("\t");
                    for(int x = 0; x <6; x++)
                    {
                        if(x==0 & (dirLongArray[i].DIR_Attr>>x)&1 == 1)//Shifts all bits in the ATTR to find which is true
                        {
                            printf("R");
                        }
                        else if(x==1 & (dirLongArray[i].DIR_Attr>>x)&1 == 1)
                        {
                            printf("H");
                        }
                        else if(x==2 & (dirLongArray[i].DIR_Attr>>x)&1 == 1)
                        {
                            printf("S");
                        }
                        else if(x==3 & (dirLongArray[i].DIR_Attr>>x)&1 == 1)
                        {
                            printf("V");
                        }
                        else if(x==4 & (dirLongArray[i].DIR_Attr>>x)&1 == 1)
                        {
                            printf("D");
                        }
                        else if(x==5 & (dirLongArray[i].DIR_Attr>>x)&1 == 1)
                        {
                            printf("A");
                        }
                        else
                        {
                            printf("-");
                        }
                    }
                    printf("\t");
                    printf("File Size:%d", dirLongArray[i].DIR_FileSize);//Print file size
                    printf("\t");
                    i--;//Go to previous long
                    int endMarker = i;//Set new end marker to this long
                    while (dirLongArray[i].DIR_Attr == 15)//Check if long
                    {
                      DirectoryLong* longEntry = (DirectoryLong*)&dirLongArray[i];
                      for(int x = 0; x<10; x+=2)//Print every other character due to Unicode
                      {
                        if((int)longEntry->LDIR_Name1[x]<255)//Check if character has an ASCII value
                        {
                            printf("%c",longEntry->LDIR_Name1[x]);//Print character
                        }
                      }
                      for(int x = 0; x<12; x+=2)
                      {
                        if((int)longEntry->LDIR_Name2[x]<255)
                        {
                            printf("%c",longEntry->LDIR_Name2[x]);
                        }
                      }
                      for(int x = 0; x<4; x+=2)
                      {
                        if((int)longEntry->LDIR_Name3[x]<255)
                        {
                            printf("%c",longEntry->LDIR_Name3[x]);
                        }
                      }
                      i--;//Go to previous long  
                    }
                    printf("\n");
                    endMarker++;//Increment end marker to go past current section of longs
                    i = endMarker;
                }  
            }
            else//All the same below except for Short Directory entries
            {
                printf("File Index:%d",i);
                printf("\t");
                printf("Starting Cluster: %d",dirLongArray[i].DIR_FstClusHI+dirLongArray[i].DIR_FstClusLO);
                printf("\t");
                printf("Y:%d M:%d D:%d", 1980+((dirLongArray[i].DIR_WrtDate&0x7C00)>>10),((dirLongArray[i].DIR_WrtDate & 0x3E0)>>5),(dirLongArray[i].DIR_WrtDate & 0x1F));
                printf("\t");
                printf("H:%d M:%d S:%d",((dirLongArray[i].DIR_WrtTime&0x7C00)>>10),((dirLongArray[i].DIR_WrtTime & 0x3E0)>>5),(dirLongArray[i].DIR_WrtTime & 0x1F));
                printf("\t");
                for(int x = 0; x <6; x++)
                    {
                        if(x==0 & (dirLongArray[i].DIR_Attr>>x)&1 == 1)
                        {
                            printf("R");
                        }
                        else if(x==1 & (dirLongArray[i].DIR_Attr>>x)&1 == 1)
                        {
                            printf("H");
                        }
                        else if(x==2 & (dirLongArray[i].DIR_Attr>>x)&1 == 1)
                        {
                            printf("S");
                        }
                        else if(x==3 & (dirLongArray[i].DIR_Attr>>x)&1 == 1)
                        {
                            printf("V");
                        }
                        else if(x==4 & (dirLongArray[i].DIR_Attr>>x)&1 == 1)
                        {
                            printf("D");
                        }
                        else if(x==5 & (dirLongArray[i].DIR_Attr>>x)&1 == 1)
                        {
                            printf("A");
                        }
                        else
                        {
                            printf("-");
                        }
                    }
                printf("\t");
                printf("File Size:%d",dirLongArray[i].DIR_FileSize);
                printf("\t");
                for(int x = 0; x<11; x++)
                {
                    printf("%c",dirLongArray[i].DIR_Name[x]);
                }
                printf("\n");
            }
        }
    }
}

int fileClusters(int clusterNum, u_int16_t clusBuf[], BootSector* bootPoint)
{
    for(int i = 0; i< bootPoint->BPB_FATSz16*256; i++)
    {
        if(clusBuf[i]==clusterNum)
            {
            while(clusBuf[i] != 65535)
            {
                printf("%d\n",clusBuf[i]);
                i++;
            }
            printf("%d\n",clusBuf[i]);
            }
    }
}


